namespace Fast_Play_Midi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlRoll = new System.Windows.Forms.Panel();
            this.btnLoadMidi = new System.Windows.Forms.Button();
            this.lblInfo = new System.Windows.Forms.Label();
            this.btnZoomIn = new System.Windows.Forms.Button();
            this.btnZoomOut = new System.Windows.Forms.Button();
            this.btnFit = new System.Windows.Forms.Button();
            this.btnSaveMidi = new System.Windows.Forms.Button();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.lstMidiFiles = new System.Windows.Forms.ListBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Combo_output = new System.Windows.Forms.ComboBox();
            this.txtBPM = new System.Windows.Forms.TextBox();
            this.Txtnote = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.optPlay = new System.Windows.Forms.RadioButton();
            this.optAdd = new System.Windows.Forms.RadioButton();
            this.optDelete = new System.Windows.Forms.RadioButton();
            this.pnlTimeline = new System.Windows.Forms.Panel();
            this.chkLoop = new System.Windows.Forms.CheckBox();
            this.Button1 = new System.Windows.Forms.Button();
            this.ComboGridResolution = new System.Windows.Forms.ComboBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // pnlRoll
            // 
            this.pnlRoll.AutoScroll = true;
            this.pnlRoll.Location = new System.Drawing.Point(12, 42);
            this.pnlRoll.Name = "pnlRoll";
            this.pnlRoll.Size = new System.Drawing.Size(1356, 609);
            this.pnlRoll.TabIndex = 0;
            this.pnlRoll.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlRoll_Paint);
            this.pnlRoll.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlRoll_MouseDown);
            this.pnlRoll.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlRoll_MouseMove);
            this.pnlRoll.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlRoll_MouseUp);
            this.pnlRoll.Resize += new System.EventHandler(this.pnlRoll_Resize);
            // 
            // btnLoadMidi
            // 
            this.btnLoadMidi.Location = new System.Drawing.Point(1398, 44);
            this.btnLoadMidi.Name = "btnLoadMidi";
            this.btnLoadMidi.Size = new System.Drawing.Size(101, 42);
            this.btnLoadMidi.TabIndex = 1;
            this.btnLoadMidi.Text = "Load midi";
            this.btnLoadMidi.UseVisualStyleBackColor = true;
            this.btnLoadMidi.Click += new System.EventHandler(this.btnLoadMidi_Click);
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfo.Location = new System.Drawing.Point(12, 672);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(62, 23);
            this.lblInfo.TabIndex = 2;
            this.lblInfo.Text = "Label1";
            // 
            // btnZoomIn
            // 
            this.btnZoomIn.Location = new System.Drawing.Point(1398, 92);
            this.btnZoomIn.Name = "btnZoomIn";
            this.btnZoomIn.Size = new System.Drawing.Size(47, 44);
            this.btnZoomIn.TabIndex = 3;
            this.btnZoomIn.Text = "In";
            this.btnZoomIn.UseVisualStyleBackColor = true;
            this.btnZoomIn.Click += new System.EventHandler(this.btnZoomIn_Click);
            // 
            // btnZoomOut
            // 
            this.btnZoomOut.Location = new System.Drawing.Point(1556, 92);
            this.btnZoomOut.Name = "btnZoomOut";
            this.btnZoomOut.Size = new System.Drawing.Size(50, 44);
            this.btnZoomOut.TabIndex = 4;
            this.btnZoomOut.Text = "Out";
            this.btnZoomOut.UseVisualStyleBackColor = true;
            this.btnZoomOut.Click += new System.EventHandler(this.btnZoomOut_Click);
            // 
            // btnFit
            // 
            this.btnFit.Location = new System.Drawing.Point(1450, 92);
            this.btnFit.Name = "btnFit";
            this.btnFit.Size = new System.Drawing.Size(101, 44);
            this.btnFit.TabIndex = 5;
            this.btnFit.Text = "FIT";
            this.btnFit.UseVisualStyleBackColor = true;
            this.btnFit.Click += new System.EventHandler(this.btnFit_Click);
            // 
            // btnSaveMidi
            // 
            this.btnSaveMidi.Location = new System.Drawing.Point(1505, 44);
            this.btnSaveMidi.Name = "btnSaveMidi";
            this.btnSaveMidi.Size = new System.Drawing.Size(101, 42);
            this.btnSaveMidi.TabIndex = 6;
            this.btnSaveMidi.Text = "Save midi";
            this.btnSaveMidi.UseVisualStyleBackColor = true;
            this.btnSaveMidi.Click += new System.EventHandler(this.btnSaveMidi_Click);
            // 
            // btnPlay
            // 
            this.btnPlay.Location = new System.Drawing.Point(1398, 142);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(101, 63);
            this.btnPlay.TabIndex = 7;
            this.btnPlay.Text = "Play";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(1505, 142);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(101, 63);
            this.btnStop.TabIndex = 8;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // lstMidiFiles
            // 
            this.lstMidiFiles.FormattingEnabled = true;
            this.lstMidiFiles.Location = new System.Drawing.Point(1398, 211);
            this.lstMidiFiles.Name = "lstMidiFiles";
            this.lstMidiFiles.Size = new System.Drawing.Size(208, 160);
            this.lstMidiFiles.TabIndex = 9;
            this.lstMidiFiles.SelectedIndexChanged += new System.EventHandler(this.lstMidiFiles_SelectedIndexChanged);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(1398, 612);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(83, 16);
            this.Label2.TabIndex = 13;
            this.Label2.Text = "MIDI   OUT";
            // 
            // Combo_output
            // 
            this.Combo_output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Combo_output.FormattingEnabled = true;
            this.Combo_output.Location = new System.Drawing.Point(1398, 628);
            this.Combo_output.Name = "Combo_output";
            this.Combo_output.Size = new System.Drawing.Size(172, 23);
            this.Combo_output.TabIndex = 12;
            this.Combo_output.SelectedIndexChanged += new System.EventHandler(this.Combo_output_SelectedIndexChanged);
            // 
            // txtBPM
            // 
            this.txtBPM.Location = new System.Drawing.Point(1408, 487);
            this.txtBPM.Name = "txtBPM";
            this.txtBPM.Size = new System.Drawing.Size(65, 20);
            this.txtBPM.TabIndex = 14;
            this.txtBPM.Text = "120";
            this.txtBPM.TextChanged += new System.EventHandler(this.txtBPM_TextChanged);
            // 
            // Txtnote
            // 
            this.Txtnote.Location = new System.Drawing.Point(1479, 487);
            this.Txtnote.Name = "Txtnote";
            this.Txtnote.Size = new System.Drawing.Size(103, 20);
            this.Txtnote.TabIndex = 15;
            this.Txtnote.Text = "note";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(1405, 468);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(35, 16);
            this.Label1.TabIndex = 16;
            this.Label1.Text = "bpm";
            // 
            // optPlay
            // 
            this.optPlay.AutoSize = true;
            this.optPlay.Location = new System.Drawing.Point(1404, 388);
            this.optPlay.Name = "optPlay";
            this.optPlay.Size = new System.Drawing.Size(80, 17);
            this.optPlay.TabIndex = 17;
            this.optPlay.TabStop = true;
            this.optPlay.Text = "Only Sound";
            this.optPlay.UseVisualStyleBackColor = true;
            // 
            // optAdd
            // 
            this.optAdd.AutoSize = true;
            this.optAdd.Location = new System.Drawing.Point(1404, 411);
            this.optAdd.Name = "optAdd";
            this.optAdd.Size = new System.Drawing.Size(68, 17);
            this.optAdd.TabIndex = 18;
            this.optAdd.TabStop = true;
            this.optAdd.Text = "Add note";
            this.optAdd.UseVisualStyleBackColor = true;
            // 
            // optDelete
            // 
            this.optDelete.AutoSize = true;
            this.optDelete.Location = new System.Drawing.Point(1404, 434);
            this.optDelete.Name = "optDelete";
            this.optDelete.Size = new System.Drawing.Size(65, 17);
            this.optDelete.TabIndex = 19;
            this.optDelete.TabStop = true;
            this.optDelete.Text = "Del note";
            this.optDelete.UseVisualStyleBackColor = true;
            // 
            // pnlTimeline
            // 
            this.pnlTimeline.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnlTimeline.Location = new System.Drawing.Point(12, 3);
            this.pnlTimeline.Name = "pnlTimeline";
            this.pnlTimeline.Size = new System.Drawing.Size(1356, 31);
            this.pnlTimeline.TabIndex = 20;
            this.pnlTimeline.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTimeline_MouseDown);
            this.pnlTimeline.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTimeline_MouseUp);
            // 
            // chkLoop
            // 
            this.chkLoop.Appearance = System.Windows.Forms.Appearance.Button;
            this.chkLoop.AutoSize = true;
            this.chkLoop.BackColor = System.Drawing.Color.DarkGray;
            this.chkLoop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkLoop.ForeColor = System.Drawing.Color.Black;
            this.chkLoop.Location = new System.Drawing.Point(1533, 388);
            this.chkLoop.Name = "chkLoop";
            this.chkLoop.Size = new System.Drawing.Size(53, 30);
            this.chkLoop.TabIndex = 21;
            this.chkLoop.Text = "loop";
            this.chkLoop.UseVisualStyleBackColor = false;
            this.chkLoop.CheckedChanged += new System.EventHandler(this.chkLoop_CheckedChanged);
            // 
            // Button1
            // 
            this.Button1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Button1.Location = new System.Drawing.Point(1579, 617);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(47, 37);
            this.Button1.TabIndex = 22;
            this.Button1.Text = "About";
            this.Button1.UseVisualStyleBackColor = false;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // ComboGridResolution
            // 
            this.ComboGridResolution.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboGridResolution.FormattingEnabled = true;
            this.ComboGridResolution.Location = new System.Drawing.Point(1400, 559);
            this.ComboGridResolution.Name = "ComboGridResolution";
            this.ComboGridResolution.Size = new System.Drawing.Size(161, 23);
            this.ComboGridResolution.TabIndex = 23;
            this.ComboGridResolution.SelectedIndexChanged += new System.EventHandler(this.ComboGridResolution_SelectedIndexChanged);
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(1397, 540);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(94, 16);
            this.Label3.TabIndex = 24;
            this.Label3.Text = "Resolu_Grid";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.ForeColor = System.Drawing.Color.Maroon;
            this.Label4.Location = new System.Drawing.Point(1116, 672);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(507, 25);
            this.Label4.TabIndex = 25;
            this.Label4.Text = "USING  MARVELOUS  DRYWETMIDI  LIBRARY";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(1372, 10);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(235, 16);
            this.Label5.TabIndex = 26;
            this.Label5.Text = "<-----Use the bar to sound parts !!";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1635, 705);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.ComboGridResolution);
            this.Controls.Add(this.Button1);
            this.Controls.Add(this.chkLoop);
            this.Controls.Add(this.pnlTimeline);
            this.Controls.Add(this.optDelete);
            this.Controls.Add(this.optAdd);
            this.Controls.Add(this.optPlay);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Txtnote);
            this.Controls.Add(this.txtBPM);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Combo_output);
            this.Controls.Add(this.lstMidiFiles);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.btnSaveMidi);
            this.Controls.Add(this.btnFit);
            this.Controls.Add(this.btnZoomOut);
            this.Controls.Add(this.btnZoomIn);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.btnLoadMidi);
            this.Controls.Add(this.pnlRoll);
            this.Name = "Form1";
            this.Text = "USING  MARVELOUS  DRYWETMIDI  LIBRARY";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlRoll;
        private System.Windows.Forms.Button btnLoadMidi;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Button btnZoomIn;
        private System.Windows.Forms.Button btnZoomOut;
        private System.Windows.Forms.Button btnFit;
        private System.Windows.Forms.Button btnSaveMidi;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.ListBox lstMidiFiles;
        private System.Windows.Forms.Label Label2;
        private System.Windows.Forms.ComboBox Combo_output;
        private System.Windows.Forms.TextBox txtBPM;
        private System.Windows.Forms.TextBox Txtnote;
        private System.Windows.Forms.Label Label1;
        private System.Windows.Forms.RadioButton optPlay;
        private System.Windows.Forms.RadioButton optAdd;
        private System.Windows.Forms.RadioButton optDelete;
        private System.Windows.Forms.Panel pnlTimeline;
        private System.Windows.Forms.CheckBox chkLoop;
        private System.Windows.Forms.Button Button1;
        private System.Windows.Forms.ComboBox ComboGridResolution;
        private System.Windows.Forms.Label Label3;
        private System.Windows.Forms.Label Label4;
        private System.Windows.Forms.Label Label5;
    }
}
