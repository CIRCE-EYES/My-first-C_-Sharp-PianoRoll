using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using Melanchall.DryWetMidi.Common;
using Melanchall.DryWetMidi.Core;
using Melanchall.DryWetMidi.Devices;
using Melanchall.DryWetMidi.Interaction;

namespace Fast_Play_Midi
{
    public partial class Form1 : Form
    {
        private readonly List<MidiNoteView> midiNotes = new List<MidiNoteView>();

        // 1=1/4, 2=1/8, 4=1/16, 8=1/32, 16=1/64, 24=1/96, 30=1/120
        private int gridDivision = 8; // Default 1/32
        private double ticksPerGrid = 60.0;

        private int ticksPerQuarter = 480;

        private int cellWidth = 24;
        private const int RowHeight = 14;
        private const int PianoNotesCount = 128;
        private const int HeaderHeight = 36;
        private const int LeftPianoWidth = 90;
        private const int MinCellWidth = 4;
        private const int MaxCellWidth = 80;

        private string loadedFileName = "";
        private int maxGridUnits = 64;
        private string midiFolderPath;
        private readonly Dictionary<string, string> midiFileMap = new Dictionary<string, string>();
        private int minNote = 0;
        private int maxNote = 127;

        public Playback _playback;
        private OutputDevice _outputDevice = null;
        private int previewNote = -1;
        private readonly System.Windows.Forms.Timer playbackTimer = new System.Windows.Forms.Timer();
        private readonly Dictionary<MidiNoteView, bool> activeNotes = new Dictionary<MidiNoteView, bool>();
        private long currentPlayTick = 0;
        private int BPM = 120;
        private long maxTick = 0;
        private long scrubTick = 0;
        private bool isScrubbing = false;

        private readonly Stopwatch playbackClock = new Stopwatch();

        // ============================
        // ORIGINAL MIDI
        // ============================
        private MidiFile currentMidi;

        // ============================
        // EDITING
        // ============================
        private MidiNoteView selectedNote = null;
        private bool isDragging = false;
        private bool isResizing = false;
        private int dragOffsetX;
        private int dragOffsetY;

        private const int ResizeMargin = 6;

        public Form1()
        {
            InitializeComponent();
        }

        private static SevenBitNumber ToSevenBit(int value)
        {
            value = Math.Max(0, Math.Min(127, value));
            return (SevenBitNumber)(byte)value;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            EnableDoubleBuffering(pnlRoll);

            midiFolderPath = Path.Combine(Application.StartupPath, "MIDIFILES");

            if (!Directory.Exists(midiFolderPath))
                Directory.CreateDirectory(midiFolderPath);

            LoadMidiList();

            lblInfo.Text = "No MIDI file loaded";

            ConfigurarComboGridResolution();

            LoadMidiOutputs();

            playbackTimer.Interval = 30;
            playbackTimer.Tick += PlaybackTimer_Tick;

            optPlay.Checked = true;
            chkLoop.Checked = false;

            if (txtBPM != null)
                txtBPM.Text = BPM.ToString();

            CreateEmptyMidi();

            btnFit.PerformClick();
        }

        private void LoadMidiOutputs()
        {
            Combo_output.Items.Clear();
            Combo_output.Enabled = true;
            _outputDevice = null;

            try
            {
                var devices = OutputDevice.GetAll().ToList();

                if (devices.Count == 0)
                {
                    Combo_output.Items.Add("No MIDI output");
                    Combo_output.SelectedIndex = 0;
                    Combo_output.Enabled = false;
                    _outputDevice = null;
                    return;
                }

                Combo_output.Items.Add("Select MIDI output...");

                foreach (var dev in devices)
                    Combo_output.Items.Add(dev.Name);

                Combo_output.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                Combo_output.Items.Clear();
                Combo_output.Items.Add("MIDI listing error");
                Combo_output.SelectedIndex = 0;
                Combo_output.Enabled = false;
                _outputDevice = null;

                MessageBox.Show("MIDI outputs could not be listed:" + Environment.NewLine + ex.Message);
            }
        }

        private void ConfigurarComboGridResolution()
        {
            ComboGridResolution.Items.Clear();

            ComboGridResolution.Items.Add("1/4");
            ComboGridResolution.Items.Add("1/8");
            ComboGridResolution.Items.Add("1/16");
            ComboGridResolution.Items.Add("1/32");
            ComboGridResolution.Items.Add("1/64");
            ComboGridResolution.Items.Add("1/96");
            ComboGridResolution.Items.Add("1/120");

            ComboGridResolution.DropDownStyle = ComboBoxStyle.DropDownList;
            ComboGridResolution.SelectedItem = "1/32";
        }

        private string GetGridText()
        {
            if (ComboGridResolution != null && ComboGridResolution.SelectedItem != null)
                return ComboGridResolution.SelectedItem.ToString();

            return "1/" + (gridDivision * 4).ToString();
        }

        private void ComboGridResolution_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboGridResolution.SelectedItem == null)
                return;

            switch (ComboGridResolution.SelectedItem.ToString())
            {
                case "1/4":
                    gridDivision = 1;
                    break;
                case "1/8":
                    gridDivision = 2;
                    break;
                case "1/16":
                    gridDivision = 4;
                    break;
                case "1/32":
                    gridDivision = 8;
                    break;
                case "1/64":
                    gridDivision = 16;
                    break;
                case "1/96":
                    gridDivision = 24;
                    break;
                case "1/120":
                    gridDivision = 30;
                    break;
            }

            ticksPerGrid = ticksPerQuarter / (double)gridDivision;

            foreach (var n in midiNotes)
            {
                double startGrid = n.StartTick / ticksPerGrid;
                double endGrid = (n.StartTick + n.LengthTick) / ticksPerGrid;

                int qStart = Convert.ToInt32(Math.Round(startGrid));
                int qEnd = Convert.ToInt32(Math.Round(endGrid));

                if (qEnd <= qStart)
                    qEnd = qStart + 1;

                n.GridX = qStart;
                n.GridWidth = qEnd - qStart;
            }

            AutoFitMidiView();

            lblInfo.Text = $"{loadedFileName} | Notes: {midiNotes.Count} | TPQN: {ticksPerQuarter} | Grid: {GetGridText()} | Zoom: {cellWidth}";
        }

        private void AutoScrollPlayback()
        {
            int currentX = LeftPianoWidth + Convert.ToInt32((currentPlayTick / ticksPerGrid) * cellWidth);
            int targetScrollX = currentX - pnlRoll.ClientSize.Width / 2;

            if (targetScrollX < 0)
                targetScrollX = 0;

            int currentScrollX = -pnlRoll.AutoScrollPosition.X;
            int smooth = Convert.ToInt32(currentScrollX + (targetScrollX - currentScrollX) * 0.2);

            pnlRoll.AutoScrollPosition = new Point(smooth, -pnlRoll.AutoScrollPosition.Y);
        }

        private void chkLoop_CheckedChanged(object sender, EventArgs e)
        {
            if (chkLoop.Checked)
            {
                chkLoop.BackColor = Color.Red;
                chkLoop.ForeColor = Color.White;
            }
            else
            {
                chkLoop.BackColor = Color.DarkGray;
                chkLoop.ForeColor = Color.Black;
            }
        }

        private void CreateEmptyMidi()
        {
            var midi = new MidiFile();
            var track = new TrackChunk();

            midi.Chunks.Add(track);
            midi.ReplaceTempoMap(TempoMap.Create(Tempo.FromBeatsPerMinute(BPM)));

            // CORREGIDO: DryWetMIDI espera short, no int.
            midi.TimeDivision = new TicksPerQuarterNoteTimeDivision((short)ticksPerQuarter);

            currentMidi = midi;
            ticksPerGrid = ticksPerQuarter / (double)gridDivision;
        }

        private void Combo_output_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (_outputDevice != null)
                {
                    _outputDevice.Dispose();
                    _outputDevice = null;
                }

                if (Combo_output.SelectedItem == null)
                    return;

                string selectedName = Combo_output.SelectedItem.ToString();

                if (selectedName == "Select MIDI output...")
                {
                    _outputDevice = null;
                    return;
                }

                if (selectedName == "No MIDI output")
                {
                    _outputDevice = null;
                    return;
                }

                if (selectedName == "MIDI listing error")
                {
                    _outputDevice = null;
                    return;
                }

                _outputDevice = OutputDevice.GetByName(selectedName);
            }
            catch (Exception ex)
            {
                _outputDevice = null;
                MessageBox.Show("Error selecting MIDI device:" + Environment.NewLine + ex.Message);
            }
        }

        private void lstMidiFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstMidiFiles.SelectedItem == null)
                return;

            string name = lstMidiFiles.SelectedItem.ToString();

            if (midiFileMap.ContainsKey(name))
                LoadMidi(midiFileMap[name]);
        }

        private void LoadMidiList()
        {
            lstMidiFiles.Items.Clear();
            midiFileMap.Clear();

            var files = Directory.GetFiles(midiFolderPath, "*.mid");

            foreach (var file in files)
            {
                string nameWithoutExt = Path.GetFileNameWithoutExtension(file);

                lstMidiFiles.Items.Add(nameWithoutExt);
                midiFileMap[nameWithoutExt] = file;
            }
        }

        private void AutoScrollWhileDragging(int mx)
        {
            int scrollMargin = 40;
            int scrollSpeed = 20;

            int visibleRight = pnlRoll.AutoScrollPosition.X * -1 + pnlRoll.ClientSize.Width;

            if (mx > visibleRight - scrollMargin)
            {
                pnlRoll.AutoScrollPosition = new Point(
                    (pnlRoll.AutoScrollPosition.X * -1) + scrollSpeed,
                    pnlRoll.AutoScrollPosition.Y * -1);
            }
        }

        private void SimularMouseDown(MidiNoteView n)
        {
            if (_outputDevice == null)
                return;

            _outputDevice.SendEvent(new NoteOnEvent(ToSevenBit(n.NoteNumber), ToSevenBit(n.Velocity)));
            activeNotes[n] = true;
        }

        private void SimularMouseUp(MidiNoteView n)
        {
            if (_outputDevice == null)
                return;

            _outputDevice.SendEvent(new NoteOffEvent(ToSevenBit(n.NoteNumber), ToSevenBit(0)));
            activeNotes[n] = false;
        }

        private void pnlRoll_MouseDown(object sender, MouseEventArgs e)
        {
            int mx = e.X - pnlRoll.AutoScrollPosition.X;
            int my = e.Y - pnlRoll.AutoScrollPosition.Y;

            selectedNote = null;
            isDragging = false;
            isResizing = false;

            int gridX = Convert.ToInt32(Math.Floor((mx - LeftPianoWidth) / (double)cellWidth));
            gridX = Math.Max(0, gridX);

            int noteNumber = 127 - ((my - HeaderHeight) / RowHeight);
            noteNumber = Math.Max(0, Math.Min(127, noteNumber));

            foreach (var n in midiNotes)
            {
                int x = LeftPianoWidth + n.GridX * cellWidth;
                int y = HeaderHeight + (127 - n.NoteNumber) * RowHeight;
                int w = n.GridWidth * cellWidth;

                var rect = new Rectangle(x, y, w, RowHeight);

                if (rect.Contains(mx, my))
                {
                    selectedNote = n;

                    if (Math.Abs(mx - (x + w)) < ResizeMargin)
                    {
                        isResizing = true;
                    }
                    else
                    {
                        isDragging = true;
                        dragOffsetX = mx - x;
                        dragOffsetY = my - y;
                    }

                    break;
                }
            }

            if (optPlay.Checked)
            {
                Txtnote.Text = GetNoteName(noteNumber) + " (" + noteNumber + ")";

                if (_outputDevice != null)
                {
                    _outputDevice.SendEvent(new NoteOnEvent(ToSevenBit(noteNumber), ToSevenBit(100)));
                    previewNote = noteNumber;
                }

                return;
            }

            if (optDelete.Checked)
            {
                if (selectedNote != null)
                {
                    midiNotes.Remove(selectedNote);
                    selectedNote = null;
                    RecalculateGridSize();
                }

                pnlRoll.Invalidate();
                return;
            }

            if (optAdd.Checked)
            {
                if (selectedNote != null)
                    return;

                var newNote = new MidiNoteView
                {
                    NoteNumber = noteNumber,
                    Velocity = 100,
                    GridX = gridX,
                    GridWidth = 4,
                    StartTick = Convert.ToInt64(gridX * ticksPerGrid),
                    LengthTick = Convert.ToInt64(4 * ticksPerGrid)
                };

                midiNotes.Add(newNote);
                selectedNote = newNote;

                RecalculateGridSize();
                pnlRoll.Invalidate();
            }
        }

        private void pnlRoll_MouseMove(object sender, MouseEventArgs e)
        {
            int mx = e.X - pnlRoll.AutoScrollPosition.X;
            int my = e.Y - pnlRoll.AutoScrollPosition.Y;

            bool hoverResize = false;

            foreach (var n in midiNotes)
            {
                int x = LeftPianoWidth + n.GridX * cellWidth;
                int y = HeaderHeight + (127 - n.NoteNumber) * RowHeight;
                int w = n.GridWidth * cellWidth;

                if (mx >= x && mx <= x + w && my >= y && my <= y + RowHeight)
                {
                    if (Math.Abs(mx - (x + w)) <= ResizeMargin)
                        hoverResize = true;

                    break;
                }
            }

            if (hoverResize)
            {
                if (pnlRoll.Cursor != Cursors.SizeWE)
                    pnlRoll.Cursor = Cursors.SizeWE;
            }
            else
            {
                if (pnlRoll.Cursor != Cursors.Default)
                    pnlRoll.Cursor = Cursors.Default;
            }

            if (selectedNote == null)
                return;

            if (isDragging)
            {
                double newGridX = (mx - LeftPianoWidth - dragOffsetX) / (double)cellWidth;
                selectedNote.GridX = Math.Max(0, Convert.ToInt32(Math.Round(newGridX)));

                int note = 127 - ((my - HeaderHeight) / RowHeight);
                note = Math.Max(0, Math.Min(127, note));
                selectedNote.NoteNumber = note;

                selectedNote.StartTick = Convert.ToInt64(selectedNote.GridX * ticksPerGrid);
                selectedNote.LengthTick = Convert.ToInt64(selectedNote.GridWidth * ticksPerGrid);

                RecalculateGridSize();
                AutoScrollWhileDragging(mx);
            }
            else if (isResizing)
            {
                int startX = LeftPianoWidth + selectedNote.GridX * cellWidth;
                double newWidth = (mx - startX) / (double)cellWidth;

                selectedNote.GridWidth = Math.Max(1, Convert.ToInt32(Math.Round(newWidth)));

                selectedNote.StartTick = Convert.ToInt64(selectedNote.GridX * ticksPerGrid);
                selectedNote.LengthTick = Convert.ToInt64(selectedNote.GridWidth * ticksPerGrid);

                RecalculateGridSize();
                AutoScrollWhileDragging(mx);
            }

            pnlRoll.Invalidate();
        }

        private void RecalculateGridSize()
        {
            if (midiNotes != null && midiNotes.Count > 0)
                maxGridUnits = midiNotes.Max(n => n.GridX + n.GridWidth);
            else
                maxGridUnits = 64;

            if (maxGridUnits < 16)
                maxGridUnits = 16;

            maxTick = Convert.ToInt64(maxGridUnits * ticksPerGrid);
            UpdateScrollArea();
        }

        private void AutoFitMidiView()
        {
            if (midiNotes == null || midiNotes.Count == 0)
            {
                RecalculateGridSize();
                pnlRoll.AutoScrollPosition = new Point(0, 0);
                pnlRoll.Invalidate();
                return;
            }

            RecalculateGridSize();

            int availableWidth = Math.Max(100, pnlRoll.ClientSize.Width - LeftPianoWidth - 30);
            int fittedCellWidth = Convert.ToInt32(Math.Floor(availableWidth / (double)Math.Max(1, maxGridUnits)));

            if (fittedCellWidth < MinCellWidth)
                fittedCellWidth = MinCellWidth;
            if (fittedCellWidth > MaxCellWidth)
                fittedCellWidth = MaxCellWidth;

            cellWidth = fittedCellWidth;
            UpdateScrollArea();

            minNote = midiNotes.Min(n => n.NoteNumber);
            maxNote = midiNotes.Max(n => n.NoteNumber);

            int visualMinNote = Math.Max(0, minNote - 4);
            int visualMaxNote = Math.Min(127, maxNote + 4);

            int centerPitch = (visualMinNote + visualMaxNote) / 2;
            int centerY = HeaderHeight + (127 - centerPitch) * RowHeight;
            int targetScrollY = centerY - (pnlRoll.ClientSize.Height / 2);

            if (targetScrollY < 0)
                targetScrollY = 0;

            int maxScrollY = Math.Max(0, pnlRoll.AutoScrollMinSize.Height - pnlRoll.ClientSize.Height);

            if (targetScrollY > maxScrollY)
                targetScrollY = maxScrollY;

            pnlRoll.AutoScrollPosition = new Point(0, targetScrollY);
            pnlRoll.Invalidate();
        }

        private void pnlRoll_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
            isResizing = false;

            if (_outputDevice != null && previewNote >= 0)
            {
                _outputDevice.SendEvent(new NoteOffEvent(ToSevenBit(previewNote), ToSevenBit(0)));
                previewNote = -1;
            }
        }

        private void EnableDoubleBuffering(Control ctrl)
        {
            Type t = ctrl.GetType();
            PropertyInfo pi = t.GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);

            if (pi != null)
                pi.SetValue(ctrl, true, null);
        }

        private void btnLoadMidi_Click(object sender, EventArgs e)
        {
            using (var ofd = new OpenFileDialog())
            {
                ofd.Filter = "MIDI files|*.mid;*.midi|All files|*.*";
                ofd.Title = "Select MIDI file";

                if (ofd.ShowDialog() == DialogResult.OK)
                    LoadMidi(ofd.FileName);
            }
        }

        private void btnZoomIn_Click(object sender, EventArgs e)
        {
            cellWidth += 8;

            if (cellWidth > MaxCellWidth)
                cellWidth = MaxCellWidth;

            UpdateScrollArea();
            pnlRoll.Invalidate();
        }

        private void btnZoomOut_Click(object sender, EventArgs e)
        {
            cellWidth -= 8;

            if (cellWidth < MinCellWidth)
                cellWidth = MinCellWidth;

            UpdateScrollArea();
            pnlRoll.Invalidate();
        }

        private void btnFit_Click(object sender, EventArgs e)
        {
            if (maxGridUnits <= 0)
                return;

            int availableWidth = Math.Max(100, pnlRoll.ClientSize.Width - LeftPianoWidth - 30);
            int fitted = Convert.ToInt32(Math.Floor(availableWidth / (double)Math.Max(1, maxGridUnits)));

            if (fitted < MinCellWidth)
                fitted = MinCellWidth;
            if (fitted > MaxCellWidth)
                fitted = MaxCellWidth;

            cellWidth = fitted;

            UpdateScrollArea();
            pnlRoll.Invalidate();
        }

        private void LoadMidi(string filePath)
        {
            try
            {
                midiNotes.Clear();

                MidiFile midi = MidiFile.Read(filePath);
                var notes = midi.GetNotes();

                var division = midi.TimeDivision as TicksPerQuarterNoteTimeDivision;

                if (division != null)
                    ticksPerQuarter = division.TicksPerQuarterNote;
                else
                    ticksPerQuarter = 480;

                ticksPerGrid = ticksPerQuarter / (double)gridDivision;

                foreach (var n in notes)
                {
                    long startTick = Convert.ToInt64(n.Time);
                    long lengthTick = Convert.ToInt64(n.Length);
                    long endTick = startTick + lengthTick;

                    double startGrid = startTick / ticksPerGrid;
                    double endGrid = endTick / ticksPerGrid;

                    int qStart = Convert.ToInt32(Math.Round(startGrid));
                    int qEnd = Convert.ToInt32(Math.Round(endGrid));

                    if (qEnd <= qStart)
                        qEnd = qStart + 1;

                    midiNotes.Add(new MidiNoteView
                    {
                        NoteNumber = Convert.ToInt32(n.NoteNumber),
                        Velocity = Convert.ToInt32(n.Velocity),
                        StartTick = startTick,
                        LengthTick = lengthTick,
                        GridX = qStart,
                        GridWidth = qEnd - qStart
                    });
                }

                loadedFileName = Path.GetFileName(filePath);

                AutoFitMidiView();

                lblInfo.Text = $"{loadedFileName} | Notes: {midiNotes.Count} | TPQN: {ticksPerQuarter} | Grid: {GetGridText()} | Zoom: {cellWidth}";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading MIDI: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateScrollArea()
        {
            int contentWidth = LeftPianoWidth + (maxGridUnits * cellWidth) + 200;
            int contentHeight = HeaderHeight + (PianoNotesCount * RowHeight) + 10;

            pnlRoll.AutoScrollMinSize = new Size(contentWidth, contentHeight);
        }

        private void pnlRoll_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            g.SmoothingMode = SmoothingMode.None;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            g.TranslateTransform(pnlRoll.AutoScrollPosition.X, pnlRoll.AutoScrollPosition.Y);

            DrawBackground(g);
            DrawHeader(g);
            DrawPiano(g);
            DrawGrid(g);
            DrawNotes(g);
            DrawPlaybackCursor(g);

            if (scrubTick > 0)
            {
                int x = LeftPianoWidth + Convert.ToInt32((scrubTick / ticksPerGrid) * cellWidth);

                using (var p = new Pen(Color.Yellow, 2))
                    g.DrawLine(p, x, 0, x, pnlRoll.AutoScrollMinSize.Height);
            }
        }

        private void DrawBackground(Graphics g)
        {
            int w = pnlRoll.AutoScrollMinSize.Width;
            int h = pnlRoll.AutoScrollMinSize.Height;

            g.FillRectangle(Brushes.White, 0, 0, w, h);

            using (var br = new SolidBrush(Color.FromArgb(245, 245, 245)))
                g.FillRectangle(br, 0, 0, LeftPianoWidth, h);

            using (var br = new SolidBrush(Color.FromArgb(235, 235, 235)))
                g.FillRectangle(br, 0, 0, w, HeaderHeight);
        }

        private void DrawHeader(Graphics g)
        {
            int w = pnlRoll.AutoScrollMinSize.Width;
            int h = pnlRoll.AutoScrollMinSize.Height;

            g.DrawLine(Pens.DimGray, 0, HeaderHeight - 1, w, HeaderHeight - 1);
            g.DrawLine(Pens.DimGray, LeftPianoWidth - 1, 0, LeftPianoWidth - 1, h);

            int stepsPerBeat = gridDivision;
            int stepsPerBar = gridDivision * 4;

            for (int i = 0; i <= maxGridUnits + stepsPerBar; i++)
            {
                int x = LeftPianoWidth + i * cellWidth;

                if (i % stepsPerBar == 0)
                {
                    using (var p = new Pen(Color.Black, 2))
                        g.DrawLine(p, x, 0, x, h);

                    int barNum = (i / stepsPerBar) + 1;
                    g.DrawString(barNum.ToString(), Font, Brushes.Black, x + 3, 4);
                }
                else if (i % stepsPerBeat == 0)
                {
                    g.DrawLine(Pens.Gray, x, HeaderHeight, x, h);

                    int beatNum = ((i % stepsPerBar) / stepsPerBeat) + 1;
                    g.DrawString(beatNum.ToString(), Font, Brushes.DarkSlateBlue, x + 2, 18);
                }
                else
                {
                    g.DrawLine(Pens.Gainsboro, x, HeaderHeight, x, h);
                }
            }
        }

        private void DrawGrid(Graphics g)
        {
            int w = pnlRoll.AutoScrollMinSize.Width;
            int h = pnlRoll.AutoScrollMinSize.Height;

            int stepsPerBeat = gridDivision;
            int stepsPerBar = gridDivision * 4;

            for (int midiNote = 0; midiNote <= 127; midiNote++)
            {
                int y = HeaderHeight + (127 - midiNote) * RowHeight;
                int noteInOctave = midiNote % 12;

                if (IsBlackKey(noteInOctave))
                {
                    using (var br = new SolidBrush(Color.FromArgb(235, 235, 235)))
                        g.FillRectangle(br, LeftPianoWidth, y, w - LeftPianoWidth, RowHeight);
                }
                else
                {
                    g.FillRectangle(Brushes.White, LeftPianoWidth, y, w - LeftPianoWidth, RowHeight);
                }
            }

            for (int i = 0; i <= PianoNotesCount; i++)
            {
                int y = HeaderHeight + i * RowHeight;
                g.DrawLine(Pens.Gainsboro, LeftPianoWidth, y, w, y);
            }

            for (int i = 0; i <= maxGridUnits + stepsPerBar; i++)
            {
                int x = LeftPianoWidth + i * cellWidth;

                if (i % stepsPerBar == 0)
                {
                    using (var p = new Pen(Color.Black, 2))
                        g.DrawLine(p, x, 0, x, h);
                }
                else if (i % stepsPerBeat == 0)
                {
                    g.DrawLine(Pens.Gray, x, HeaderHeight, x, h);
                }
                else
                {
                    g.DrawLine(Pens.LightGray, x, HeaderHeight, x, h);
                }
            }

            g.DrawLine(Pens.DimGray, LeftPianoWidth, 0, LeftPianoWidth, h);
        }

        private void DrawPiano(Graphics g)
        {
            for (int midiNote = 0; midiNote <= 127; midiNote++)
            {
                int y = HeaderHeight + (127 - midiNote) * RowHeight;
                string noteName = GetNoteName(midiNote);
                int noteInOctave = midiNote % 12;
                bool isBlack = IsBlackKey(noteInOctave);

                var keyRect = new Rectangle(0, y, LeftPianoWidth, RowHeight);

                if (isBlack)
                {
                    g.FillRectangle(Brushes.Black, keyRect);
                    g.DrawRectangle(Pens.DimGray, keyRect);
                    g.DrawString(noteName, Font, Brushes.White, 4, y - 1);
                }
                else
                {
                    g.FillRectangle(Brushes.WhiteSmoke, keyRect);
                    g.DrawRectangle(Pens.Gray, keyRect);
                    g.DrawString(noteName, Font, Brushes.Black, 4, y - 1);
                }
            }
        }

        private void DrawNotes(Graphics g)
        {
            foreach (var n in midiNotes)
            {
                int x = LeftPianoWidth + n.GridX * cellWidth;
                int y = HeaderHeight + (127 - n.NoteNumber) * RowHeight + 1;

                int w = n.GridWidth * cellWidth;
                int h = RowHeight - 2;

                Color c;

                if (activeNotes.ContainsKey(n) && activeNotes[n])
                    c = Color.Red;
                else if (ReferenceEquals(n, selectedNote))
                    c = Color.Orange;
                else
                    c = VelocityToColor(n.Velocity);

                using (var br = new SolidBrush(c))
                using (var pn = new Pen(Color.Black))
                {
                    g.FillRectangle(br, x, y, w, h);
                    g.DrawRectangle(pn, x, y, w, h);
                }
            }
        }

        private Color VelocityToColor(int velocity)
        {
            int v = Math.Max(0, Math.Min(127, velocity));

            int r = 40 + Convert.ToInt32((v / 127.0) * 150);
            int g = 110 + Convert.ToInt32((v / 127.0) * 80);
            int b = 230 - Convert.ToInt32((v / 127.0) * 120);

            return Color.FromArgb(r, g, b);
        }

        private bool IsBlackKey(int noteInOctave)
        {
            switch (noteInOctave)
            {
                case 1:
                case 3:
                case 6:
                case 8:
                case 10:
                    return true;
                default:
                    return false;
            }
        }

        private string GetNoteName(int midiNote)
        {
            string[] names = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
            int octave = (midiNote / 12) - 1;

            return names[midiNote % 12] + octave.ToString();
        }

        private void pnlRoll_Resize(object sender, EventArgs e)
        {
            pnlRoll.Invalidate();
        }

        private class MidiNoteView
        {
            public int NoteNumber { get; set; }
            public int Velocity { get; set; }
            public long StartTick { get; set; }
            public long LengthTick { get; set; }
            public int GridX { get; set; }
            public int GridWidth { get; set; }
        }

        private void btnSaveMidi_Click(object sender, EventArgs e)
        {
            if (midiNotes.Count == 0)
                return;

            using (var sfd = new SaveFileDialog())
            {
                sfd.Filter = "MIDI|*.mid";

                if (sfd.ShowDialog() == DialogResult.OK)
                    SaveMidi(sfd.FileName);
            }
        }

        private void SaveMidi(string path)
        {
            try
            {
                var notes = new List<Note>();

                foreach (var n in midiNotes)
                {
                    long startTick = Convert.ToInt64(n.GridX * ticksPerGrid);
                    long lengthTick = Convert.ToInt64(n.GridWidth * ticksPerGrid);

                    if (lengthTick < 1)
                        lengthTick = 1;
                    if (startTick < 0)
                        startTick = 0;

                    var midiNote = new Note(ToSevenBit(n.NoteNumber));

                    midiNote.Time = startTick;
                    midiNote.Length = lengthTick;
                    midiNote.Velocity = ToSevenBit(n.Velocity);

                    notes.Add(midiNote);
                }

                TrackChunk trackChunk = notes.ToTrackChunk();
                var midi = new MidiFile(trackChunk);

                // CORREGIDO: DryWetMIDI espera short, no int.
                midi.TimeDivision = new TicksPerQuarterNoteTimeDivision((short)ticksPerQuarter);

                midi.Write(path);

                MessageBox.Show("MIDI saved successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving MIDI: " + ex.Message);
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_playback != null)
            {
                _playback.Stop();
                _playback.Dispose();
                _playback = null;
            }

            if (_outputDevice != null)
            {
                _outputDevice.Dispose();
                _outputDevice = null;
            }

            base.OnFormClosing(e);
        }

        private void txtBPM_TextChanged(object sender, EventArgs e)
        {
            int value;

            if (int.TryParse(txtBPM.Text, out value))
                BPM = Math.Max(20, Math.Min(1500, value));
        }

        private void PlaybackTimer_Tick(object sender, EventArgs e)
        {
            if (_outputDevice == null)
                return;

            double seconds = playbackClock.Elapsed.TotalSeconds;
            double ticksPerSecond = (ticksPerQuarter * BPM) / 60.0;

            currentPlayTick = Convert.ToInt64(seconds * ticksPerSecond);

            if (maxTick > 0 && currentPlayTick >= maxTick)
            {
                if (chkLoop.Checked)
                {
                    foreach (var n in activeNotes.Keys.ToList())
                    {
                        if (activeNotes[n])
                            _outputDevice.SendEvent(new NoteOffEvent(ToSevenBit(n.NoteNumber), ToSevenBit(0)));
                    }

                    playbackClock.Restart();
                    currentPlayTick = 0;
                    activeNotes.Clear();
                }
                else
                {
                    btnStop.PerformClick();
                    return;
                }
            }

            int currentX = LeftPianoWidth + Convert.ToInt32((currentPlayTick / ticksPerGrid) * cellWidth);

            foreach (var n in midiNotes)
            {
                int x = LeftPianoWidth + n.GridX * cellWidth;
                int w = n.GridWidth * cellWidth;

                int left = x;
                int right = x + w;

                if (!activeNotes.ContainsKey(n))
                    activeNotes[n] = false;

                bool isInside = currentX >= left && currentX <= right;

                if (isInside)
                {
                    if (!activeNotes[n])
                    {
                        _outputDevice.SendEvent(new NoteOnEvent(ToSevenBit(n.NoteNumber), ToSevenBit(n.Velocity)));
                        activeNotes[n] = true;
                    }
                }
                else
                {
                    if (activeNotes[n])
                    {
                        _outputDevice.SendEvent(new NoteOffEvent(ToSevenBit(n.NoteNumber), ToSevenBit(0)));
                        activeNotes[n] = false;
                    }
                }
            }

            int targetScrollX = currentX - pnlRoll.ClientSize.Width / 2;

            if (targetScrollX < 0)
                targetScrollX = 0;

            int currentScrollX = -pnlRoll.AutoScrollPosition.X;
            int smooth = Convert.ToInt32(currentScrollX + (targetScrollX - currentScrollX) * 0.2);

            pnlRoll.AutoScrollPosition = new Point(smooth, -pnlRoll.AutoScrollPosition.Y);
            pnlRoll.Invalidate();
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            RecalculateGridSize();
            playbackClock.Restart();
            currentPlayTick = 0;
            activeNotes.Clear();
            playbackTimer.Start();

            try
            {
                if (midiNotes.Count == 0)
                    return;

                if (_outputDevice == null)
                {
                    MessageBox.Show("Please select a MIDI output from the port list first.");
                    playbackTimer.Stop();
                    return;
                }

                if (_playback != null)
                {
                    _playback.Stop();
                    _playback.Dispose();
                    _playback = null;
                }

                var midi = new MidiFile();
                var trackChunk = new TrackChunk();
                var manager = trackChunk.ManageNotes();

                foreach (var n in midiNotes)
                {
                    long startTick = Convert.ToInt64(n.GridX * ticksPerGrid);
                    long lengthTick = Convert.ToInt64(n.GridWidth * ticksPerGrid);

                    if (startTick < 0)
                        startTick = 0;
                    if (lengthTick < 1)
                        lengthTick = 1;

                    var note = new Note(ToSevenBit(n.NoteNumber));

                    note.Time = startTick;
                    note.Length = lengthTick;
                    note.Velocity = ToSevenBit(n.Velocity);

                    manager.Notes.Add(note);
                }

                midi.Chunks.Add(trackChunk);

                // CORREGIDO: DryWetMIDI espera short, no int.
                midi.TimeDivision = new TicksPerQuarterNoteTimeDivision((short)ticksPerQuarter);

                _playback = midi.GetPlayback(_outputDevice);
                _playback.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Playback error: " + ex.Message);
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            playbackTimer.Stop();

            if (_playback != null)
            {
                _playback.Stop();
                _playback.Dispose();
                _playback = null;
            }

            if (_outputDevice != null)
            {
                foreach (var n in activeNotes.Keys.ToList())
                {
                    if (activeNotes[n])
                        _outputDevice.SendEvent(new NoteOffEvent(ToSevenBit(n.NoteNumber), ToSevenBit(0)));
                }
            }

            activeNotes.Clear();
            currentPlayTick = 0;

            pnlRoll.Invalidate();
        }

        private void DrawPlaybackCursor(Graphics g)
        {
            if (isScrubbing)
                return;

            if (!playbackTimer.Enabled)
                return;

            double gridX = currentPlayTick / ticksPerGrid;
            int x = LeftPianoWidth + Convert.ToInt32(gridX * cellWidth);

            using (var p = new Pen(Color.Red, 2))
                g.DrawLine(p, x, 0, x, pnlRoll.AutoScrollMinSize.Height);
        }

        private void pnlTimeline_MouseDown(object sender, MouseEventArgs e)
        {
            int mx = e.X - pnlRoll.AutoScrollPosition.X;

            double gridX = (mx - LeftPianoWidth) / (double)cellWidth;
            gridX = Math.Max(0, gridX);

            scrubTick = Convert.ToInt64(gridX * ticksPerGrid);
            currentPlayTick = scrubTick;

            isScrubbing = true;

            PlayNotesAtTick(scrubTick);

            pnlRoll.Invalidate();
            pnlTimeline.Invalidate();
        }

        private void PlayNotesAtTick(long tick)
        {
            if (_outputDevice == null)
                return;

            foreach (var n in activeNotes.Keys.ToList())
            {
                if (activeNotes[n])
                {
                    _outputDevice.SendEvent(new NoteOffEvent(ToSevenBit(n.NoteNumber), ToSevenBit(0)));
                    activeNotes[n] = false;
                }
            }

            foreach (var n in midiNotes)
            {
                long startTick = Convert.ToInt64(n.GridX * ticksPerGrid);
                long endTick = Convert.ToInt64((n.GridX + n.GridWidth) * ticksPerGrid);

                if (tick >= startTick && tick <= endTick)
                {
                    _outputDevice.SendEvent(new NoteOnEvent(ToSevenBit(n.NoteNumber), ToSevenBit(n.Velocity)));
                    activeNotes[n] = true;
                }
            }
        }

        private void pnlTimeline_MouseUp(object sender, MouseEventArgs e)
        {
            isScrubbing = false;

            if (_outputDevice != null)
            {
                foreach (var n in activeNotes.Keys.ToList())
                {
                    if (activeNotes[n])
                    {
                        _outputDevice.SendEvent(new NoteOffEvent(ToSevenBit(n.NoteNumber), ToSevenBit(0)));
                        activeNotes[n] = false;
                    }
                }
            }

            scrubTick = -1;

            pnlRoll.Invalidate();
            pnlTimeline.Invalidate();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string rutaImagen = Path.Combine(Application.StartupPath, "about.png");

            if (!File.Exists(rutaImagen))
            {
                MessageBox.Show("Image file not found:" + Environment.NewLine + rutaImagen);
                return;
            }

            var frmAbout = new Form();

            frmAbout.Text = "About";
            frmAbout.StartPosition = FormStartPosition.CenterParent;
            frmAbout.FormBorderStyle = FormBorderStyle.FixedDialog;
            frmAbout.MaximizeBox = false;
            frmAbout.MinimizeBox = false;
            frmAbout.ShowInTaskbar = false;
            frmAbout.BackColor = Color.Black;
            frmAbout.Padding = new Padding(10);

            var pic = new PictureBox();

            using (Image tempImg = Image.FromFile(rutaImagen))
                pic.Image = new Bitmap(tempImg);

            pic.SizeMode = PictureBoxSizeMode.Zoom;
            pic.Dock = DockStyle.Fill;
            pic.BackColor = Color.Black;

            frmAbout.ClientSize = new Size(600, 400);
            frmAbout.Controls.Add(pic);

            frmAbout.FormClosed += (s, args) =>
            {
                if (pic.Image != null)
                {
                    pic.Image.Dispose();
                    pic.Image = null;
                }
            };

            frmAbout.ShowDialog(this);
        }
    }
}